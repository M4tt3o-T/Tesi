 
_________________________________________________________________
                   S E N S I C H I P S                           
-----------------------------------------------------------------
         l e a r n i n g   m i c r o s e n s o r s     
_________________________________________________________________
 
                - SLM-Studio, Ver 1.0.9 -              
 
 
Date: 04-10(October)-2023
 
Experiment starts at: 23:37:52.316
 
-----------------------------------------------------------------
 

System Name:  DESKTOP-MUBUKGB
Logged User:  Francesco
 
Operating system: Windows 10
 
Processor Name: AMD Ryzen 7 5700X 8-Core Processor             
Microarchitecture: Zen 3
Frequency (GHz): 3.4
 
Total memory: 17.1 GB
Available memory: 5.0 GB

_________________________________________________________________


_________________________________________________________________
Optional notes: 



_________________________________________________________________


_________________________________________________________________

                    Experiment Batch:

Experiment File Name: SENSIMOX_SNAu_TEST_LOOP

-----------------------------------------------------------------
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sensichips>
  <experiment delay="0" globalRepetition="1151" 
	id="SENSIMOX_SNAu_TEST_LOOP" outputDecimation="1">

<!--200HZ(IN-PHASE,QUADRATURE) PER OGNI TEMP -->
  <sensor save="ALL" plot="IN-PHASE"
		  autorange="false" SETwaitGET = "0" filter = "1"
		  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150"   SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
	  <val>OFFCHIP_SENSIMOX_SnAu</val>
  </sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200"  SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250" SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor> 

	 <sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300" SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350" SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400" SENSIMOX_Frequency="200" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>


	  <!-- 78kHZ(SINGLE) , 200HZ(IN-PHASE,QUADRATURE) PER OGNI TEMP  -->
  <sensor save="ALL" plot="IN-PHASE"
		  autorange="false" SETwaitGET = "0" filter = "1"
		  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150" SENSIMOX_Rsense="5000">
	  <val>OFFCHIP_SENSIMOX_SnAu</val>
  </sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor> 

	 <sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350" SENSIMOX_Rsense="5000">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>


	  <!-- 312.5kHZ(IN-PHASE,QUADRATURE) PER OGNI OXIDE -->
    <sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1" autorange="false" >
         <val>ONCHIP_ALUMINUM_OXIDE_OUT4</val>
   </sensor>

   <sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1" autorange="false" >
         <val>ONCHIP_ALUMINUM_OXIDE_OUT7</val>
   </sensor> 


 </experiment>
</sensichips>


-----------------------------------------------------------------
_________________________________________________________________


_________________________________________________________________

       Experiment Batch (showing all default values)

-----------------------------------------------------------------
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sensichips>
  <experiment fillBufferBeforeStart="false" delay="0" globalRepetition="1151" 
	id="SENSIMOX_SNAu_TEST_LOOP" outputDecimation="1">

<!--200HZ(IN-PHASE,QUADRATURE) PER OGNI TEMP -->
  <sensor save="ALL" plot="IN-PHASE"
		  autorange="false" SETwaitGET = "0" filter = "1"
		  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150"   SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
	  <val>OFFCHIP_SENSIMOX_SnAu</val>
  </sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200"  SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250" SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor> 

	 <sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300" SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350" SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400" SENSIMOX_Frequency="200" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>


	  <!-- 78kHZ(SINGLE) , 200HZ(IN-PHASE,QUADRATURE) PER OGNI TEMP  -->
  <sensor save="ALL" plot="IN-PHASE"
		  autorange="false" SETwaitGET = "0" filter = "1"
		  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150" SENSIMOX_Rsense="5000">
	  <val>OFFCHIP_SENSIMOX_SnAu</val>
  </sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor> 

	 <sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350" SENSIMOX_Rsense="5000">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>


	  <!-- 312.5kHZ(IN-PHASE,QUADRATURE) PER OGNI OXIDE -->
    <sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1" autorange="false" portLabel="PORT5" portValue="00101" rsense="50000" inGain="50" outGain="4" contacts="TWO" frequency="78125.0" Harmonic="FIRST_HARMONIC" DCBiasP="0" DCBiasN="0" modeVI="VOUT_IIN" measureTechnique="EIS" measureType="CONDUCTANCE" phaseShiftMode="Quadrants" phaseShift="0" iq="IN_PHASE" conversionRate="500" NData="1" inPortADC="IA" sequentialMode="false" burstMode="false" fillBufferBeforeStart="false" >
         <val>ONCHIP_ALUMINUM_OXIDE_OUT4</val>
   </sensor>

   <sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1" autorange="false" portLabel="PORT5" portValue="00101" rsense="50000" inGain="50" outGain="7" contacts="TWO" frequency="78125.0" Harmonic="FIRST_HARMONIC" DCBiasP="0" DCBiasN="0" modeVI="VOUT_IIN" measureTechnique="EIS" measureType="CONDUCTANCE" phaseShiftMode="Quadrants" phaseShift="0" iq="IN_PHASE" conversionRate="500" NData="1" inPortADC="IA" sequentialMode="false" burstMode="false" fillBufferBeforeStart="false" >
         <val>ONCHIP_ALUMINUM_OXIDE_OUT7</val>
   </sensor> 


 </experiment>
</sensichips>


-----------------------------------------------------------------
_________________________________________________________________

 
 
_________________________________________________________________
                   System Ports Info:                            
_________________________________________________________________
 
-----------------------------------------------------------------
 
Port name: Communications Port (COM1)
Port description: Communications Port (COM1)
Port location: 0-0.0
Port path: \\.\COM1
System port name: COM1
Port name: USB-SERIAL CH340 (COM5)
Port description: USB2.0-Serial
Port location: 0-1.6
Port path: \\.\COM5
System port name: COM5
-----------------------------------------------------------------
