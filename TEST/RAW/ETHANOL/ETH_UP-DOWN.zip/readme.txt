 
_________________________________________________________________
                   S E N S I C H I P S                           
-----------------------------------------------------------------
         l e a r n i n g   m i c r o s e n s o r s     
_________________________________________________________________
 
                - SLM-Studio, Ver 1.2.9 -              
 
 
Date: 16-08(August)-2025
 
Experiment starts at: 10:54:05.604
 
-----------------------------------------------------------------
 

 
Operating system: Windows 11
 
Processor Name: Snapdragon(R) X 12-core X1E80100 @ 3.40 GHz
Microarchitecture: unknown
Frequency: 2.976 GHz
 
Total memory: 16.8 GB
Available memory: 4.5 GB
 

_________________________________________________________________
Optional notes: 



_________________________________________________________________


                    SLM-Studio Settings 

Configuration:        [RUN11][AUTO]
Driver:               [WINUX_COMUSB]
Serial port:          [COM4][AUTO]
Protocol:             [SENSIBUS][No Address]
Cluster ID:           [0X0B]
Reference Voltage:    [RATIOMETRIC]
Measurement folder:   [./measures]
Controller:           [ESP8266]
Baud rate:            [460800]
API owner:            [PC]
Bandgap operation:    [NONE]
Host controller:      [PC]

_________________________________________________________________


                    Experiment Batch 

Experiment File Name: SENSIMOX_SNAu_TEST_LOOP.xml

-----------------------------------------------------------------
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sensichips>
  <experiment delay="0" globalRepetition="1100" 
	id="SENSIMOX_SNAu_TEST_LOOP" outputDecimation="1">

<!--200HZ(IN-PHASE,QUADRATURE) PER OGNI TEMP -->
  <sensor save="ALL" plot="IN-PHASE"
		  autorange="false" SETwaitGET = "0" filter = "1"
		  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150"   SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
	  <val>OFFCHIP_SENSIMOX_SnAu</val>
  </sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200"  SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250" SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor> 

	 <sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300" SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>
 
	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350" SENSIMOX_Frequency="200" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400" SENSIMOX_Frequency="200" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>


	  <!-- 78kHZ(SINGLE) , 200HZ(IN-PHASE,QUADRATURE) PER OGNI TEMP -->
  <sensor save="ALL" plot="IN-PHASE"
		  autorange="false" SETwaitGET = "0" filter = "1"
		  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150" SENSIMOX_Rsense="5000">
	  <val>OFFCHIP_SENSIMOX_SnAu</val>
  </sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor> 

	 <sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>
 
	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>


	  <!-- 312.5kHZ(IN-PHASE,QUADRATURE) PER OGNI OXIDE -->
    <sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1" autorange="false" >
         <val>ONCHIP_ALUMINUM_OXIDE_OUT4</val>
   </sensor>

   <sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1" autorange="false" >
         <val>ONCHIP_ALUMINUM_OXIDE_OUT7</val>
   </sensor> 


 </experiment>
</sensichips>



-----------------------------------------------------------------
_________________________________________________________________


_________________________________________________________________

       Experiment Batch (showing all default parameters)

-----------------------------------------------------------------
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sensichips>
  <experiment fillBufferBeforeStart="false" delay="0" globalRepetition="1100" 
	id="SENSIMOX_SNAu_TEST_LOOP" outputDecimation="1">


  <sensor save="ALL" plot="IN-PHASE"
		  autorange="false" SETwaitGET = "0" filter = "1"
		  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150"   SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
	  <val>OFFCHIP_SENSIMOX_SnAu</val>
  </sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200"  SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250" SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor> 

	 <sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300" SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>
 
	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350" SENSIMOX_Frequency="200" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400" SENSIMOX_Frequency="200" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>


	  
  <sensor save="ALL" plot="IN-PHASE"
		  autorange="false" SETwaitGET = "0" filter = "1"
		  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150" SENSIMOX_Rsense="5000">
	  <val>OFFCHIP_SENSIMOX_SnAu</val>
  </sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor> 

	 <sensor save="ALL" plot="IN-PHASE"
	 	autorange="false" SETwaitGET = "0" filter = "1"
	 	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300" SENSIMOX_Rsense="5000">
            <val>OFFCHIP_SENSIMOX_SnAu</val>
	</sensor>
 
	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>

	  <sensor save="ALL" plot="IN-PHASE"
			  autorange="false" SETwaitGET = "0" filter = "1"
			  SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400" SENSIMOX_Rsense="500">
		  <val>OFFCHIP_SENSIMOX_SnAu</val>
	  </sensor>


	  
    <sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1" autorange="false" portLabel="PORT5" portValue="00101" rsense="50000" inGain="50" outGain="4" contacts="TWO" frequency="78125.0" Harmonic="FIRST_HARMONIC" DCBiasP="0" DCBiasN="0" modeVI="VOUT_IIN" measureTechnique="EIS" measureType="CONDUCTANCE" phaseShiftMode="Quadrants" phaseShift="0" iq="IN_PHASE" conversionRate="500" NData="1" inPortADC="IA" sequentialMode="false" burstMode="false" fillBufferBeforeStart="false" >
         <val>ONCHIP_ALUMINUM_OXIDE_OUT4</val>
   </sensor>

   <sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1" autorange="false" portLabel="PORT5" portValue="00101" rsense="50000" inGain="50" outGain="7" contacts="TWO" frequency="78125.0" Harmonic="FIRST_HARMONIC" DCBiasP="0" DCBiasN="0" modeVI="VOUT_IIN" measureTechnique="EIS" measureType="CONDUCTANCE" phaseShiftMode="Quadrants" phaseShift="0" iq="IN_PHASE" conversionRate="500" NData="1" inPortADC="IA" sequentialMode="false" burstMode="false" fillBufferBeforeStart="false" >
         <val>ONCHIP_ALUMINUM_OXIDE_OUT7</val>
   </sensor> 


 </experiment>
</sensichips>



-----------------------------------------------------------------
_________________________________________________________________

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
_________________________________________________________________
