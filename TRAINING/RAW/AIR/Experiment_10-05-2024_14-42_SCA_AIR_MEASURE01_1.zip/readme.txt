 
_________________________________________________________________
                   S E N S I C H I P S                           
-----------------------------------------------------------------
         l e a r n i n g   m i c r o s e n s o r s     
_________________________________________________________________
 
                - SLM-Studio, Ver 1.1.2 -              
 
 
Date: 10-05(May)-2024
 
Experiment starts at: 14:42:04.651
 
-----------------------------------------------------------------
 
Country Name: Italy
Region Name: 
City Name: 

Computer Name:  Tesno-Ryzen
Logged User:  tesno
 
Operating system: Windows 11
 
Processor Name: AMD Ryzen 5 3600 6-Core Processor              
Microarchitecture: Zen 2
Frequency: 3.6 GHz
 
Total memory: 17.1 GB
Available memory: 5.7 GB
 
Installation folder: X:\Programmi\Sensichips\SLM-Studio

_________________________________________________________________
Optional notes: 



_________________________________________________________________


                    SLM-Studio Settings 

Configuration:        [AUTO]
Driver:               [WINUX_COMUSB]
Serial port:          [COM5][AUTO]
Protocol:             [SENSIBUS][No Address]
Cluster ID:           [0X08]
Reference Voltage:    [RATIOMETRIC]
Measurement folder:   [./measures]
Controller:           [ESP8266]
Baud rate:            [460800]
API owner:            [PC]
Bandgap operation:    [NONE]
Host controller:      [PC]

_________________________________________________________________


                    Experiment Batch 

Experiment File Name: SCA_Training.xml

-----------------------------------------------------------------
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sensichips>
  <experiment delay="0" globalRepetition="1000" calibration="200" 
	id="SCA_Training" outputDecimation="1" >

<!--200HZ(IN-PHASE,QUADRATURE) PER OGNI TEMP -->
	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		 OFFCHIP_SENSIMOX_SnAu
	</sensor> 

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350"
	SENSIMOX_Frequency="200"SENSIMOX_Rsense="500">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400"
	SENSIMOX_Frequency="200"SENSIMOX_Rsense="500">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>


	  <!-- 78kHZ(SINGLE) , 200HZ(IN-PHASE,QUADRATURE) PER OGNI TEMP -->
	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor> 

	<sensor save="ALL" plot="IN-PHASE"
	 autorange="false" SETwaitGET = "0" filter = "1"
	 SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350"
	SENSIMOX_Rsense="500">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400"
	SENSIMOX_Rsense="500">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>


	  <!-- 312.5kHZ(IN-PHASE,QUADRATURE) PER OGNI OXIDE -->
	<sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1"
	autorange="false" >
		ONCHIP_ALUMINUM_OXIDE_OUT4
	</sensor>

	<sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1"
	autorange="false" >
		ONCHIP_ALUMINUM_OXIDE_OUT7
	</sensor> 

 </experiment>
</sensichips>


-----------------------------------------------------------------
_________________________________________________________________


_________________________________________________________________

       Experiment Batch (showing all default parameters)

-----------------------------------------------------------------
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sensichips>
  <experiment fillBufferBeforeStart="false" delay="0" globalRepetition="1000" calibration="200" 
	id="SCA_Training" outputDecimation="1" >


	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		 OFFCHIP_SENSIMOX_SnAu
	</sensor> 

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350"
	SENSIMOX_Frequency="200"SENSIMOX_Rsense="500">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400"
	SENSIMOX_Frequency="200"SENSIMOX_Rsense="500">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>


	  
	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor> 

	<sensor save="ALL" plot="IN-PHASE"
	 autorange="false" SETwaitGET = "0" filter = "1"
	 SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350"
	SENSIMOX_Rsense="500">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400"
	SENSIMOX_Rsense="500">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>


	  
	<sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1"
	autorange="false" portLabel="PORT5" portValue="00101" rsense="50000" inGain="50" outGain="4" contacts="TWO" frequency="78125.0" Harmonic="FIRST_HARMONIC" DCBiasP="0" DCBiasN="0" modeVI="VOUT_IIN" measureTechnique="EIS" measureType="CONDUCTANCE" filter="1" phaseShiftMode="Quadrants" phaseShift="0" iq="IN_PHASE" conversionRate="500" NData="1" inPortADC="IA" sequentialMode="false" burstMode="false" fillBufferBeforeStart="false" >
		ONCHIP_ALUMINUM_OXIDE_OUT4
	</sensor>

	<sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1"
	autorange="false" portLabel="PORT5" portValue="00101" rsense="50000" inGain="50" outGain="7" contacts="TWO" frequency="78125.0" Harmonic="FIRST_HARMONIC" DCBiasP="0" DCBiasN="0" modeVI="VOUT_IIN" measureTechnique="EIS" measureType="CONDUCTANCE" filter="1" phaseShiftMode="Quadrants" phaseShift="0" iq="IN_PHASE" conversionRate="500" NData="1" inPortADC="IA" sequentialMode="false" burstMode="false" fillBufferBeforeStart="false" >
		ONCHIP_ALUMINUM_OXIDE_OUT7
	</sensor> 

 </experiment>
</sensichips>


-----------------------------------------------------------------
_________________________________________________________________

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
_________________________________________________________________
                          Debug Info:                            
_________________________________________________________________
 
-----------------------------------------------------------------
 
Port name: Collegamento standard seriale su Bluetooth (COM3)
Port description: BluetoothRfcommServerInsecure
Port location: 0-0.0
Port path: \\.\COM3
System port name: COM3
Port name: Porta di comunicazione (COM1)
Port description: Porta di comunicazione (COM1)
Port location: 0-0.0
Port path: \\.\COM1
System port name: COM1
Port name: USB Serial Port (COM5)
Port description: FT232R USB UART
Port location: 0-0.2
Port path: \\.\COM5
System port name: COM5
 
Jar file path: 
 
/X:/Programmi/Sensichips/SLM-Studio/SensiplusWinux.jar
 
-----------------------------------------------------------------

