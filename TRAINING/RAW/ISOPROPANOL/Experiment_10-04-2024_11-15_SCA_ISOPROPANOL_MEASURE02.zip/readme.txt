 
_________________________________________________________________
                   S E N S I C H I P S                           
-----------------------------------------------------------------
         l e a r n i n g   m i c r o s e n s o r s     
_________________________________________________________________
 
                - SLM-Studio, Ver 1.1.2 -              
 
 
Date: 10-04(April)-2024
 
Experiment starts at: 11:15:49.557
 
-----------------------------------------------------------------
 
Country Name: Italy
Region Name: 
City Name: 

Computer Name:  SENSILAB-DESKTOP
Logged User:  sensi
 
Operating system: Windows 11
 
Processor Name: Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz
Microarchitecture: Coffee Lake
Frequency: 3.192 GHz
 
Total memory: 25.6 GB
Available memory: 15.7 GB
 
Installation folder: C:\Sensichips\SLM-Studio3

_________________________________________________________________
Optional notes: 



_________________________________________________________________


                    SLM-Studio Settings 

Configuration:        [AUTO]
Driver:               [WINUX_COMUSB]
Serial port:          [COM50][AUTO]
Protocol:             [SENSIBUS][No Address]
Cluster ID:           [0X08]
Reference Voltage:    [RATIOMETRIC]
Measurement folder:   [./measures]
Controller:           [ESP8266]
Baud rate:            [460800]
API owner:            [PC]
Bandgap operation:    [NONE]
Host controller:      [PC]

_________________________________________________________________


                    Experiment Batch 

Experiment File Name: SCA_Training.xml

-----------------------------------------------------------------
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sensichips>
  <experiment delay="0" globalRepetition="1000" calibration="225"
	id="SCA_Training" outputDecimation="1" >

<!--200HZ(IN-PHASE,QUADRATURE) PER OGNI TEMP -->
	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="50000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="50000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="50000">
		 OFFCHIP_SENSIMOX_SnAu
	</sensor> 

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>


	  <!-- 78kHZ(SINGLE) , 200HZ(IN-PHASE,QUADRATURE) PER OGNI TEMP -->
	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED" SENSIMOX_Temperature="150"
	SENSIMOX_Rsense="50000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED" SENSIMOX_Temperature="200"
	SENSIMOX_Rsense="50000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED" SENSIMOX_Temperature="250"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor> 

	<sensor save="ALL" plot="IN-PHASE"
	 autorange="false" SETwaitGET = "0" filter = "1"
	 SENSIMOX_Mode="NOTUSED" SENSIMOX_Temperature="300"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED" SENSIMOX_Temperature="400"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>


	  <!-- 312.5kHZ(IN-PHASE,QUADRATURE) PER OGNI OXIDE -->
	<sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1"
	autorange="false" >
		ONCHIP_ALUMINUM_OXIDE_OUT4
	</sensor>

	<sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1"
	autorange="false" >
		ONCHIP_ALUMINUM_OXIDE_OUT7
	</sensor> 

 </experiment>
</sensichips>



-----------------------------------------------------------------
_________________________________________________________________


_________________________________________________________________

       Experiment Batch (showing all default parameters)

-----------------------------------------------------------------
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sensichips>
  <experiment fillBufferBeforeStart="false" delay="0" globalRepetition="1000" calibration="225"
	id="SCA_Training" outputDecimation="1" >


	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="150"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="50000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="200"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="50000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="250"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="50000">
		 OFFCHIP_SENSIMOX_SnAu
	</sensor> 

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="300"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="400"
	SENSIMOX_Frequency="200" SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>


	  
	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED" SENSIMOX_Temperature="150"
	SENSIMOX_Rsense="50000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED" SENSIMOX_Temperature="200"
	SENSIMOX_Rsense="50000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED" SENSIMOX_Temperature="250"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor> 

	<sensor save="ALL" plot="IN-PHASE"
	 autorange="false" SETwaitGET = "0" filter = "1"
	 SENSIMOX_Mode="NOTUSED" SENSIMOX_Temperature="300"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED"  SENSIMOX_Temperature="350"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>

	<sensor save="ALL" plot="IN-PHASE"
	autorange="false" SETwaitGET = "0" filter = "1"
	SENSIMOX_Mode="NOTUSED" SENSIMOX_Temperature="400"
	SENSIMOX_Rsense="5000">
		OFFCHIP_SENSIMOX_SnAu
	</sensor>


	  
	<sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1"
	autorange="false" portLabel="PORT5" portValue="00101" rsense="50000" inGain="50" outGain="4" contacts="TWO" frequency="78125.0" Harmonic="FIRST_HARMONIC" DCBiasP="0" DCBiasN="0" modeVI="VOUT_IIN" measureTechnique="EIS" measureType="CONDUCTANCE" filter="1" phaseShiftMode="Quadrants" phaseShift="0" iq="IN_PHASE" conversionRate="500" NData="1" inPortADC="IA" sequentialMode="false" burstMode="false" fillBufferBeforeStart="false" >
		ONCHIP_ALUMINUM_OXIDE_OUT4
	</sensor>

	<sensor save="ALL" plot="IN-PHASE,QUADRATURE" autoscale="false" filter="1"
	autorange="false" portLabel="PORT5" portValue="00101" rsense="50000" inGain="50" outGain="7" contacts="TWO" frequency="78125.0" Harmonic="FIRST_HARMONIC" DCBiasP="0" DCBiasN="0" modeVI="VOUT_IIN" measureTechnique="EIS" measureType="CONDUCTANCE" filter="1" phaseShiftMode="Quadrants" phaseShift="0" iq="IN_PHASE" conversionRate="500" NData="1" inPortADC="IA" sequentialMode="false" burstMode="false" fillBufferBeforeStart="false" >
		ONCHIP_ALUMINUM_OXIDE_OUT7
	</sensor> 

 </experiment>
</sensichips>



-----------------------------------------------------------------
_________________________________________________________________

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
_________________________________________________________________
                          Debug Info:                            
_________________________________________________________________
 
-----------------------------------------------------------------
 
Port name: USB-SERIAL CH340 (COM47)
Port description: USB2.0-Ser!
Port location: 0-6.1
Port path: \\.\COM47
System port name: COM47
Port name: USB-SERIAL CH340 (COM40)
Port description: USB2.0-Ser!
Port location: 0-6.4
Port path: \\.\COM40
System port name: COM40
Port name: USB-SERIAL CH340 (COM50)
Port description: USB2.0-Serial
Port location: 0-6.3
Port path: \\.\COM50
System port name: COM50
 
Jar file path: 
 
/C:/Sensichips/SLM-Studio3/SensiplusWinux.jar
 
-----------------------------------------------------------------

